TSB<-function(threshold, GA, days, hours) {
  P_0_40_more<-read.csv(system.file("extdata", "P_0_40+.csv", package = "TCB"),row.names=1,header = T)
  P_0_39<-read.csv(system.file("extdata", "P_0_39.csv", package = "TCB"),row.names=1,header = T)
  P_0_38<-read.csv(system.file("extdata", "P_0_38.csv", package = "TCB"),row.names=1,header = T)
  P_0_37<-read.csv(system.file("extdata", "P_0_37.csv", package = "TCB"),row.names=1,header = T)
  P_0_36<-read.csv(system.file("extdata", "P_0_36.csv", package = "TCB"),row.names=1,header = T)
  P_0_35<-read.csv(system.file("extdata", "P_0_35.csv", package = "TCB"),row.names=1,header = T)

  P_1_38_more<-read.csv(system.file("extdata", "P_1_38+.csv", package = "TCB"),row.names=1,header = T)
  P_1_37<-read.csv(system.file("extdata", "P_1_37.csv", package = "TCB"),row.names=1,header = T)
  P_1_36<-read.csv(system.file("extdata", "P_1_36.csv", package = "TCB"),row.names=1,header = T)
  P_1_35<-read.csv(system.file("extdata", "P_1_35.csv", package = "TCB"),row.names=1,header = T)

  E_0_38_more<-read.csv(system.file("extdata", "E_0_38+.csv", package = "TCB"),row.names=1,header = T)
  E_0_37<-read.csv(system.file("extdata", "E_0_37.csv", package = "TCB"),row.names=1,header = T)
  E_0_36<-read.csv(system.file("extdata", "E_0_36.csv", package = "TCB"),row.names=1,header = T)
  E_0_35<-read.csv(system.file("extdata", "E_0_35.csv", package = "TCB"),row.names=1,header = T)

  E_1_38_more<-read.csv(system.file("extdata", "E_1_38+.csv", package = "TCB"),row.names=1,header = T)
  E_1_37<-read.csv(system.file("extdata", "E_1_37.csv", package = "TCB"),row.names=1,header = T)
  E_1_36<-read.csv(system.file("extdata", "E_1_36.csv", package = "TCB"),row.names=1,header = T)
  E_1_35<-read.csv(system.file("extdata", "E_1_35.csv", package = "TCB"),row.names=1,header = T)
  ###Phototherapy thresholds with no recognized hyperbilirubinemia neurotoxicity risk factor###
 if (threshold == "P0" & GA == ">= 38 weeks" & as.numeric(days)*24+as.numeric(hours)<96 ) {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>24,round((150+as.numeric(days)*150/3+as.numeric(hours)*150/72)/17.1,1),round((100+as.numeric(hours)*100/24)/17.1,1))
  } else if (threshold == "P0" & GA == ">= 38 weeks" & as.numeric(days)*24+as.numeric(hours)>=96 ) {
    results <- round(350/17.1,1)
  } else if (threshold == "P0" & GA == "37 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(270/17.1,1),round((40+as.numeric(days)*230/3+as.numeric(hours)*230/72)/17.1,1))
  } else if (threshold == "P0" & GA == "36 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(260/17.1,1),round((40+as.numeric(days)*220/3+as.numeric(hours)*220/72)/17.1,1))
  } else if (threshold == "P0" & GA == "35 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(250/17.1,1),round((40+as.numeric(days)*210/3+as.numeric(hours)*210/72)/17.1,1))
  } else if (threshold == "P0" & GA == "34 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(240/17.1,1),round((40+as.numeric(days)*200/3+as.numeric(hours)*200/72)/17.1,1))
  } else if (threshold == "P0" & GA == "33 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(230/17.1,1),round((40+as.numeric(days)*190/3+as.numeric(hours)*190/72)/17.1,1))
  } else if (threshold == "P0" & GA == "32 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(220/17.1,1),round((40+as.numeric(days)*180/3+as.numeric(hours)*180/72)/17.1,1))
  } else if (threshold == "P0" & GA == "31 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(210/17.1,1),round((40+as.numeric(days)*170/3+as.numeric(hours)*170/72)/17.1,1))
  } else if (threshold == "P0" & GA == "30 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(200/17.1,1),round((40+as.numeric(days)*160/3+as.numeric(hours)*160/72)/17.1,1))
  } else if (threshold == "P0" & GA == "29 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(190/17.1,1),round((40+as.numeric(days)*150/3+as.numeric(hours)*150/72)/17.1,1))
  } else if (threshold == "P0" & GA == "28 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(180/17.1,1),round((40+as.numeric(days)*140/3+as.numeric(hours)*140/72)/17.1,1))
  } else if (threshold == "P0" & GA == "27 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(170/17.1,1),round((40+as.numeric(days)*130/3+as.numeric(hours)*130/72)/17.1,1))
  } else if (threshold == "P0" & GA == "26 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(160/17.1,1),round((40+as.numeric(days)*120/3+as.numeric(hours)*120/72)/17.1,1))
  } else if (threshold == "P0" & GA == "25 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(150/17.1,1),round((40+as.numeric(days)*110/3+as.numeric(hours)*110/72)/17.1,1))
  } else if (threshold == "P0" & GA == "24 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(140/17.1,1),round((40+as.numeric(days)*100/3+as.numeric(hours)*100/72)/17.1,1))
  } else if (threshold == "P0" & GA == "23 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(130/17.1,1),round((40+as.numeric(days)*90/3+as.numeric(hours)*90/72)/17.1,1))
  }

  ###Phototherapy thresholds with a recognized hyperbilirubinemia neurotoxicity risk factor###
  else if (threshold == "P1" & GA == ">= 38 weeks" & as.numeric(days) <= 4 & as.numeric(hours) <= 23) {
    results <- P_1_38_more[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "P1" & GA == ">= 38 weeks" & as.numeric(days) > 4 & as.numeric(hours) <= 23) {
    results <- 18.2
  } else if (threshold == "P1" & GA == "37 weeks" & as.numeric(days) <= 6 & as.numeric(hours) <= 23) {
    results <- P_1_37[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "P1" & GA == "37 weeks" & as.numeric(days) > 6 & as.numeric(hours) <= 23) {
    results <- 18.2
  } else if (threshold == "P1" & GA == "36 weeks") {
    results <- P_1_36[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "P1" & GA == "35 weeks") {
    results <- P_1_35[as.numeric(days)+1,as.numeric(hours)+1]
  }
  ###Exchange transfusion thresholds with no recognized hyperbilirubinemia neurotoxicity risk factor other than gestational age###
  else if (threshold == "E0" & GA == ">= 38 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>42,round(450/17.1,1),round((100+as.numeric(days)*350/1.75+as.numeric(hours)*350/42)/17.1,1))
  } else if (threshold == "E0" & GA == "37 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(370/17.1,1),round((80+as.numeric(days)*290/3+as.numeric(hours)*290/72)/17.1,1))
  } else if (threshold == "E0" & GA == "36 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(360/17.1,1),round((80+as.numeric(days)*280/3+as.numeric(hours)*280/72)/17.1,1))
  } else if (threshold == "E0" & GA == "35 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(350/17.1,1),round((80+as.numeric(days)*270/3+as.numeric(hours)*270/72)/17.1,1))
  } else if (threshold == "E0" & GA == "34 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(340/17.1,1),round((80+as.numeric(days)*260/3+as.numeric(hours)*260/72)/17.1,1))
  } else if (threshold == "E0" & GA == "33 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(330/17.1,1),round((80+as.numeric(days)*250/3+as.numeric(hours)*250/72)/17.1,1))
  } else if (threshold == "E0" & GA == "32 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(320/17.1,1),round((80+as.numeric(days)*240/3+as.numeric(hours)*240/72)/17.1,1))
  } else if (threshold == "E0" & GA == "31 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(310/17.1,1),round((80+as.numeric(days)*230/3+as.numeric(hours)*230/72)/17.1,1))
  } else if (threshold == "E0" & GA == "30 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(300/17.1,1),round((80+as.numeric(days)*220/3+as.numeric(hours)*220/72)/17.1,1))
  } else if (threshold == "E0" & GA == "29 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(290/17.1,1),round((80+as.numeric(days)*210/3+as.numeric(hours)*210/72)/17.1,1))
  } else if (threshold == "E0" & GA == "28 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(280/17.1,1),round((80+as.numeric(days)*200/3+as.numeric(hours)*200/72)/17.1,1))
  } else if (threshold == "E0" & GA == "27 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(270/17.1,1),round((80+as.numeric(days)*190/3+as.numeric(hours)*190/72)/17.1,1))
  } else if (threshold == "E0" & GA == "26 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(260/17.1,1),round((80+as.numeric(days)*180/3+as.numeric(hours)*180/72)/17.1,1))
  } else if (threshold == "E0" & GA == "25 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(250/17.1,1),round((80+as.numeric(days)*170/3+as.numeric(hours)*170/72)/17.1,1))
  } else if (threshold == "E0" & GA == "24 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(240/17.1,1),round((80+as.numeric(days)*160/3+as.numeric(hours)*160/72)/17.1,1))
  } else if (threshold == "E0" & GA == "23 weeks") {
    results <- ifelse(as.numeric(days)*24+as.numeric(hours)>72,round(230/17.1,1),round((80+as.numeric(days)*150/3+as.numeric(hours)*150/72)/17.1,1))
  }

  ###Exchange transfusion thresholds with any recognized hyperbilirubinemia neurotoxicity risk factors other than gestational age###
  else if (threshold == "E1" & GA == ">= 38 weeks") {
    results <- E_1_38_more[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "E1" & GA == "37 weeks") {
    results <- E_1_37[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "E1" & GA == "36 weeks") {
    results <- E_1_36[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "E1" & GA == "35 weeks") {
    results <- E_1_35[as.numeric(days)+1,as.numeric(hours)+1]
  }
  else{
    results <- NA
  }
  return(results)
}

