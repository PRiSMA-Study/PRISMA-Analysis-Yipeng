TSB_AAP<-function(threshold, GA, days, hours) {
  P_0_40_more<-read.csv(system.file("extdata", "P_0_40+.csv", package = "TCB"),row.names=1,header = T)
  P_0_39<-read.csv(system.file("extdata", "P_0_39.csv", package = "TCB"),row.names=1,header = T)
  P_0_38<-read.csv(system.file("extdata", "P_0_38.csv", package = "TCB"),row.names=1,header = T)
  P_0_37<-read.csv(system.file("extdata", "P_0_37.csv", package = "TCB"),row.names=1,header = T)
  P_0_36<-read.csv(system.file("extdata", "P_0_36.csv", package = "TCB"),row.names=1,header = T)
  P_0_35<-read.csv(system.file("extdata", "P_0_35.csv", package = "TCB"),row.names=1,header = T)

  P_1_38_more<-read.csv(system.file("extdata", "P_1_38+.csv", package = "TCB"),row.names=1,header = T)
  P_1_37<-read.csv(system.file("extdata", "P_1_37.csv", package = "TCB"),row.names=1,header = T)
  P_1_36<-read.csv(system.file("extdata", "P_1_36.csv", package = "TCB"),row.names=1,header = T)
  P_1_35<-read.csv(system.file("extdata", "P_1_35.csv", package = "TCB"),row.names=1,header = T)

  E_0_38_more<-read.csv(system.file("extdata", "E_0_38+.csv", package = "TCB"),row.names=1,header = T)
  E_0_37<-read.csv(system.file("extdata", "E_0_37.csv", package = "TCB"),row.names=1,header = T)
  E_0_36<-read.csv(system.file("extdata", "E_0_36.csv", package = "TCB"),row.names=1,header = T)
  E_0_35<-read.csv(system.file("extdata", "E_0_35.csv", package = "TCB"),row.names=1,header = T)

  E_1_38_more<-read.csv(system.file("extdata", "E_1_38+.csv", package = "TCB"),row.names=1,header = T)
  E_1_37<-read.csv(system.file("extdata", "E_1_37.csv", package = "TCB"),row.names=1,header = T)
  E_1_36<-read.csv(system.file("extdata", "E_1_36.csv", package = "TCB"),row.names=1,header = T)
  E_1_35<-read.csv(system.file("extdata", "E_1_35.csv", package = "TCB"),row.names=1,header = T)
  ###Phototherapy thresholds with no recognized hyperbilirubinemia neurotoxicity risk factor###
  if (threshold == "P0" & GA == ">= 40 weeks" & as.numeric(days) <= 4 & as.numeric(hours) <= 23) {
    results <- P_0_40_more[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "P0" & GA == ">= 40 weeks" & as.numeric(days) > 4 & as.numeric(hours) <= 23) {
    results <- 21.8
  } else if (threshold == "P0" & GA == "39 weeks" & as.numeric(days) <=6 & as.numeric(hours) <= 23) {
    results <- P_0_39[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "P0" & GA == "39 weeks" & as.numeric(days) > 6 & as.numeric(hours) <= 23) {
    results <- 21.8
  } else if (threshold == "P0" & GA == "38 weeks" & as.numeric(days) <=13) {
    results <- P_0_38[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "P0" & GA == "39 weeks" & as.numeric(days) > 13) {
    results <- 21.8
  } else if (threshold == "P0" & GA == "37 weeks") {
    results <- P_0_37[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "P0" & GA == "36 weeks") {
    results <- P_0_36[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "P0" & GA == "35 weeks") {
    results <- P_0_35[as.numeric(days)+1,as.numeric(hours)+1]
  }
  ###Phototherapy thresholds with a recognized hyperbilirubinemia neurotoxicity risk factor###
  else if (threshold == "P1" & GA == ">= 38 weeks" & as.numeric(days) <= 4 & as.numeric(hours) <= 23) {
    results <- P_1_38_more[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "P1" & GA == ">= 38 weeks" & as.numeric(days) > 4 & as.numeric(hours) <= 23) {
    results <- 18.2
  } else if (threshold == "P1" & GA == "37 weeks" & as.numeric(days) <= 6 & as.numeric(hours) <= 23) {
    results <- P_1_37[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "P1" & GA == "37 weeks" & as.numeric(days) > 6 & as.numeric(hours) <= 23) {
    results <- 18.2
  } else if (threshold == "P1" & GA == "36 weeks") {
    results <- P_1_36[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "P1" & GA == "35 weeks") {
    results <- P_1_35[as.numeric(days)+1,as.numeric(hours)+1]
  }
  ###Exchange transfusion thresholds with no recognized hyperbilirubinemia neurotoxicity risk factor other than gestational age###
  else if (threshold == "E0" & GA == ">= 38 weeks" & as.numeric(days) <= 4 & as.numeric(hours) <= 23) {
    results <- E_0_38_more[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "E0" & GA == ">= 38 weeks" & as.numeric(days) > 4 & as.numeric(hours) <= 23) {
    results <- 27
  } else if (threshold == "E0" & GA == "37 weeks" & as.numeric(days) <= 6 & as.numeric(hours) <= 23) {
    results <- E_0_37[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "E0" & GA == "37 weeks" & as.numeric(days) > 6 & as.numeric(hours) <= 23) {
    results <- 27
  } else if (threshold == "E0" & GA == "36 weeks") {
    results <- E_0_36[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "E0" & GA == "35 weeks") {
    results <- E_0_35[as.numeric(days)+1,as.numeric(hours)+1]
  }
  ###Exchange transfusion thresholds with any recognized hyperbilirubinemia neurotoxicity risk factors other than gestational age###
  else if (threshold == "E1" & GA == ">= 38 weeks") {
    results <- E_1_38_more[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "E1" & GA == "37 weeks") {
    results <- E_1_37[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "E1" & GA == "36 weeks") {
    results <- E_1_36[as.numeric(days)+1,as.numeric(hours)+1]
  } else if (threshold == "E1" & GA == "35 weeks") {
    results <- E_1_35[as.numeric(days)+1,as.numeric(hours)+1]
  }
  else{
    results <- NA
  }
  return(results)
}
